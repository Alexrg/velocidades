//: Playground - noun: a place where people can play

import UIKit

class velocidades {
    enum velocidad: Int{
        case Apagado = 0, VelocidadBaja = 20, VelocidadMedia = 50, VelocidadAlta = 120
        init (){
            self = .Apagado
        }
}

    class Auto : velocidades{
        var velocidades = velocidad()
    
        func cambioDeVelocidad() -> ( actual : Int, velocidadEnCadena: String){
          var actual = velocidades.rawValue
            var velocidadEnCadena: String
            switch actual {
            case 0 :
                velocidadEnCadena = "Apagado"
            case 20 :
                velocidadEnCadena = "Velocidad Baja"
            case 50 :
                velocidadEnCadena = "Velocidad Media"
            case 120 :
                velocidadEnCadena = "Velocidad Alta"
            default:
                break
            }
            return (actual, velocidadEnCadena)
    }
}

var miCoche = Auto.cambioDeVelocidad(0)